#pragma once
#include"DxLib.h"

enum BLOCKTYPE
{
	type1,
	type2,
	type3,
	type4,
	type5
};

struct BLOCK
{
	BLOCKTYPE type;
	double x;
	double y;
	int c;
};

const int blocknum = 36;
extern BLOCK block[blocknum];

void initblock(void);
void updateblock(void);
void drawblock(void);