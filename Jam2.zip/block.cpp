#include"block.h"

BLOCK block[blocknum];

int Count;

int mouse = 0;
bool mouseflag = false;
int mousex = 0;
int mousey = 0;


void initblock(void)
{
	for (int i = 0; i < blocknum; i++)
	{
		if (i == 6 || i == 12 || i == 18 || i == 24 || i == 30)
		{
			Count += 1;
		}
		int R = GetRand(4) + 1;
		if (R == 1)
		{
			block[i].type = type1;
			block[i].c = GetColor(255, 0, 0);
		}
		else if (R == 2)
		{
			block[i].type = type2;
			block[i].c = GetColor(0, 255, 0);
		}
		else if (R == 3)
		{
			block[i].type = type3;
			block[i].c = GetColor(0, 0, 255);
		}
		else if (R == 4)
		{
			block[i].type = type4;
			block[i].c = GetColor(255, 255, 0);
		}
		else if (R == 5)
		{
			block[i].type = type5;
			block[i].c = GetColor(0, 255, 255);
		}
		block[i].x = 100 + ((i * 50) - (Count * 300));
		block[i].y = 100 + (Count * 50);
	}
}
void updateblock(void)
{
	mouse = GetMouseInput();
	if ((mouse & MOUSE_INPUT_LEFT))
	{
		mouseflag = true;
		GetMousePoint(&mousex, &mousey);
	}
	if ((mouse & MOUSE_INPUT_RIGHT))
	{
		mouseflag = false;
	}
}
void drawblock(void)
{
	if(mouseflag==true)
	{
		DrawBox(mousex - 25, mousey - 25, mousex + 25, mousey + 25, 0xffffff, TRUE);
	}
	for (int i = 0; i < blocknum; i++)
	{
		DrawBox(block[i].x, block[i].y, block[i].x + 50, block[i].y + 50, block[i].c, true);
	}
}